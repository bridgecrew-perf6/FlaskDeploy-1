from flask import Flask,render_template


application = app = Flask(__name__)

@app.route('/')
def home():
	return ("<h1>Hello User</h1>")

#@app.route('/<user>')
#def user():
#	return render_template ('hello.html', user)



if __name__ == '__main__':
	app.run(debug=True)